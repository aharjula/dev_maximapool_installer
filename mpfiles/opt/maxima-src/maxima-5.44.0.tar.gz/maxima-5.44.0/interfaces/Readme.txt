This directory contains software for interfaces to Maxima:

emacs	       
	Interface for running Maxima with Emacs.

	emaxima	

		An interface for running Maxima under Emacs.
		Please send suggestions, bug reports to <belanger@truman.edu>. 
		The latest version of this package should be available at
		ftp://vh213601.truman.edu/pub/Maxima

xmaxima	       

	A GUI interface for Maxima using Tk/Tcl.


tex

	LaTex source files that describe any of the interfaces.
